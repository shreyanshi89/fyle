import { Component } from '@angular/core';

@Component({
  selector: 'front-end-internship-assignment-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'Books Library App';
}
