import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [],
  providers: [],
  imports: [
    CommonModule
  ]
})
export class CoreModule {}
